import React from "react";

function Hero() {
  return (
    <section className="section-container">
      <div>
        {/* <div>
          <div className="tank">
            <div className="bottom" />
            <div className="middle" />
            <div className="top" />
          </div>
        </div> */}
      </div>
    </section>
  );
}

export default Hero;
